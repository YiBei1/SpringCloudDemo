package com.t.springCloud.factory;

import com.t.springCloud.api.EmployeeRemoteService;
import com.t.springCloud.entity.Employee;
import com.t.springCloud.util.ResultEntity;
import feign.hystrix.FallbackFactory;
import org.springframework.stereotype.Component;

import java.util.List;
/*
* 实现consumer端服务降级功能
* 实现FallbackFactory接口是要传入@FeignClient注解标记的接口类型
* 在create()方法中返回@FeignClient注解标记的接口类型的对象,当Provider调用失败后,会执行这个对象的对应方法
* 这个类必须使用@Component注解将当前类的对象加入IOC容器,当然当前类所在包要符合包扫描的规则
* */
@Component
public class MyFallbackFactory implements FallbackFactory<EmployeeRemoteService> {

    public EmployeeRemoteService create(final Throwable throwable) {
        return new EmployeeRemoteService() {

            public Employee getEmployeeRemote() {
                return null;
            }

            public List<Employee> getEmpListRemote(String keyword) {
                return null;
            }

            public ResultEntity<Employee> getEmpWithCircuitBreaker(String signal) {
                return ResultEntity.failed("降级机制生效："+throwable.getMessage());
            }
        };
    }
}
