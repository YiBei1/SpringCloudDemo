package com.t.springCloud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.circuitbreaker.EnableCircuitBreaker;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

//@EnableDiscoveryClient    启用发现服务功能,不局限于Eureka注册中心
//@EnableEurekaClient       启用Eureka客户端功能,必须是Eureka注册中心

// 使用@EnableCircuitBreaker注解开启断路器功能
@EnableCircuitBreaker

@SpringBootApplication
public class ProviderMainType {
    public static void main(String[] args) {
        SpringApplication.run(ProviderMainType.class,args);
    }
}
